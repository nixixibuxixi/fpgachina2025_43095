/******************************************************************************
* Copyright (c) 2009 - 2020 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/


#include <stdlib.h>
#include <yfuns.h>


void abort(void)
{
  __exit(1);
}
